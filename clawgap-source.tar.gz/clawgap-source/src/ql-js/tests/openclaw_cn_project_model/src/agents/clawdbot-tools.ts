export function createOpenClawTools() {
  return [];
}
