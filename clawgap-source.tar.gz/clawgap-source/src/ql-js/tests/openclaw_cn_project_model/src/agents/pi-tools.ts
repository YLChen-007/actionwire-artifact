export function createOpenClawCodingTools() {
  return [];
}
