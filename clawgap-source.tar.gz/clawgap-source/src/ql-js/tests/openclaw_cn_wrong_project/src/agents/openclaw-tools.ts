export function createOpenClawTools() { return []; }
