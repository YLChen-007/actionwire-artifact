export function createOpenClawCodingTools() { return []; }
