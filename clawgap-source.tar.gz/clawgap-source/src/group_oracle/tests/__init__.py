"""Group-oracle tests."""
