"""Sink capability tests."""
